Voron_eye Dynamic Split-Screen/Voronoi Camera System

Add the .unitypackage to your project
Make sure That the Project has the URP and that the Forward renderer provided is set as the main one

Put the Voron_eye Rig on the scene or open the demo scene

You can add the gameobjects as targets to the target list 
The maximum is 15.

On play mode:
Use the Mouse to drag the screen and rotate the camera
The provided players can be moved with:
- Player1 WASD
- Player2 TFGH
- Player3 IJKL
- Player4 Arrows

In the inspector you'll find
Min Screen Camera Distance - Sets the minimum distance of the global camera
Max Screen Camera Distance - Sets the maximum distance of the global camera
Target Camera Distance - Sets the distance of the individual cameras
Pitch - Rotation x
Yaw - Rotation y
Roll - Rotation z
Padding - Adds an offset to the borders of the screen so the targets wont move out of the view
Voron_eye Switch Time - sets the time it takes to switch from the normal view to the split view
Split Lines - Customize Split Lines
Connceting Lines - Activate/Deactivate Connecting Lines.